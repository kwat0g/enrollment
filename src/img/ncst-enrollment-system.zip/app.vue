<template>
  <div id="app" class="min-h-screen bg-gray-50">
    <!-- Navigation Header -->
    <nav v-if="isAuthenticated" class="bg-blue-800 text-white shadow-lg sticky top-0 z-40">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
          <div class="flex items-center">
            <div class="flex-shrink-0">
              <h1 class="text-xl font-bold">NCST Enrollment System</h1>
            </div>
            <div class="ml-8 text-sm text-blue-200">
              {{ systemSettings.current_school_year }} - {{ getOrdinalSemester(systemSettings.current_semester) }} Semester
            </div>
          </div>
          <div class="flex items-center space-x-4">
            <div class="text-sm">
              <div class="font-medium">{{ user.name }}</div>
              <div class="text-blue-200 text-xs">{{ user.role === 'admin' ? 'Administrator' : user.course }}</div>
            </div>
            <button @click="logout" class="bg-blue-700 hover:bg-blue-600 px-3 py-2 rounded-md text-sm font-medium transition-colors">
              Logout
            </button>
          </div>
        </div>
      </div>
    </nav>

    <!-- System Maintenance Notice -->
    <div v-if="systemSettings.system_maintenance === 'true'" class="bg-yellow-600 text-white px-4 py-2 text-center text-sm">
      <strong>System Maintenance:</strong> The system is currently under maintenance. Some features may be unavailable.
    </div>

    <!-- Enrollment Status Banner -->
    <div v-if="isAuthenticated && systemSettings.enrollment_status" 
         :class="[
           systemSettings.enrollment_status === 'open' ? 'bg-green-600' : 'bg-red-600',
           'text-white px-4 py-2 text-center text-sm'
         ]">
      Enrollment is currently {{ systemSettings.enrollment_status.toUpperCase() }}
      <span v-if="systemSettings.enrollment_deadline" class="ml-4">
        Deadline: {{ formatDate(systemSettings.enrollment_deadline) }}
      </span>
    </div>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <!-- Login Page -->
      <div v-if="!isAuthenticated" class="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-md w-full space-y-8">
          <div>
            <div class="mx-auto h-24 w-24 bg-blue-800 rounded-full flex items-center justify-center">
              <svg class="h-12 w-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
            </div>
            <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
              NCST Enrollment System
            </h2>
            <p class="mt-2 text-center text-sm text-gray-600">
              Sign in to your account
            </p>
            <p class="mt-1 text-center text-xs text-gray-500">
              Only 2nd year students and above can access online enrollment
            </p>
          </div>
          <form class="mt-8 space-y-6" @submit.prevent="login">
            <div class="rounded-md shadow-sm -space-y-px">
              <div>
                <label for="studentId" class="sr-only">Student ID</label>
                <input
                  id="studentId"
                  v-model="loginForm.studentId"
                  name="studentId"
                  type="text"
                  required
                  class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm"
                  placeholder="Student ID (e.g., 2021-001234)"
                />
              </div>
              <div>
                <label for="lastname" class="sr-only">Last Name</label>
                <input
                  id="lastname"
                  v-model="loginForm.lastname"
                  name="lastname"
                  type="text"
                  required
                  class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm"
                  placeholder="Last Name"
                />
              </div>
            </div>

            <div v-if="loginError" class="bg-red-50 border border-red-200 rounded-md p-3">
              <div class="flex">
                <div class="flex-shrink-0">
                  <svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                  </svg>
                </div>
                <div class="ml-3">
                  <p class="text-sm text-red-800">{{ loginError }}</p>
                </div>
              </div>
            </div>

            <div>
              <button
                type="submit"
                :disabled="isLoading"
                class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <span v-if="isLoading" class="flex items-center">
                  <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Signing in...
                </span>
                <span v-else>Sign in</span>
              </button>
            </div>
          </form>
          
          <!-- Demo Credentials -->
          <div class="mt-6 p-4 bg-blue-50 rounded-md">
            <h3 class="text-sm font-medium text-blue-800 mb-2">Demo Credentials:</h3>
            <div class="text-xs text-blue-700 space-y-1">
              <div><strong>Admin:</strong> admin / admin</div>
              <div><strong>Student:</strong> 2021-001234 / Doe</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Student Dashboard -->
      <div v-else-if="user.role === 'student'" class="px-4 py-6 sm:px-0">
        <!-- Dashboard Header -->
        <div class="mb-8">
          <h1 class="text-3xl font-bold text-gray-900">Student Dashboard</h1>
          <p class="mt-2 text-gray-600">Manage your enrollment, view grades, and check accountabilities</p>
        </div>

        <!-- Quick Status Cards -->
        <div class="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
          <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
              <div class="flex items-center">
                <div class="flex-shrink-0">
                  <svg class="h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <div class="ml-5 w-0 flex-1">
                  <dl>
                    <dt class="text-sm font-medium text-gray-500 truncate">Enrollment Status</dt>
                    <dd class="text-lg font-medium text-gray-900">
                      <span :class="[
                        student.isEnrolled ? 'text-green-600' : 'text-yellow-600'
                      ]">
                        {{ student.isEnrolled ? 'Enrolled' : 'Not Enrolled' }}
                      </span>
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>

          <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
              <div class="flex items-center">
                <div class="flex-shrink-0">
                  <svg class="h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                  </svg>
                </div>
                <div class="ml-5 w-0 flex-1">
                  <dl>
                    <dt class="text-sm font-medium text-gray-500 truncate">Accountabilities</dt>
                    <dd class="text-lg font-medium text-gray-900">
                      <span :class="[
                        student.hasAccountabilities ? 'text-red-600' : 'text-green-600'
                      ]">
                        {{ student.hasAccountabilities ? 'Pending' : 'Clear' }}
                      </span>
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>

          <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
              <div class="flex items-center">
                <div class="flex-shrink-0">
                  <svg class="h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                </div>
                <div class="ml-5 w-0 flex-1">
                  <dl>
                    <dt class="text-sm font-medium text-gray-500 truncate">Current Units</dt>
                    <dd class="text-lg font-medium text-gray-900">
                      {{ student.currentEnrollment ? student.currentEnrollment.total_units : 0 }}
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>

          <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
              <div class="flex items-center">
                <div class="flex-shrink-0">
                  <svg class="h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                </div>
                <div class="ml-5 w-0 flex-1">
                  <dl>
                    <dt class="text-sm font-medium text-gray-500 truncate">Total Fee</dt>
                    <dd class="text-lg font-medium text-gray-900">
                      ₱{{ student.currentEnrollment ? formatCurrency(student.currentEnrollment.total_fee) : '0.00' }}
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Navigation Tabs -->
        <div class="border-b border-gray-200 mb-6">
          <nav class="-mb-px flex space-x-8">
            <button
              v-for="tab in studentTabs"
              :key="tab.id"
              @click="activeTab = tab.id"
              :class="[
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300',
                'whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm'
              ]"
            >
              {{ tab.name }}
            </button>
          </nav>
        </div>

        <!-- Enrollment Tab -->
        <div v-if="activeTab === 'enrollment'" class="space-y-6">
          <!-- Enrollment Blocked Notice -->
          <div v-if="student.hasAccountabilities" class="bg-red-50 border border-red-200 rounded-md p-4">
            <div class="flex">
              <div class="flex-shrink-0">
                <svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                  <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                </svg>
              </div>
              <div class="ml-3">
                <h3 class="text-sm font-medium text-red-800">Enrollment Blocked</h3>
                <p class="mt-2 text-sm text-red-700">You have pending accountabilities. Please settle them before enrolling.</p>
                <div class="mt-3">
                  <button @click="activeTab = 'accountabilities'" class="text-sm bg-red-100 text-red-800 px-3 py-1 rounded-md hover:bg-red-200">
                    View Accountabilities
                  </button>
                </div>
              </div>
            </div>
          </div>

          <!-- Enrollment Closed Notice -->
          <div v-else-if="systemSettings.enrollment_status === 'closed'" class="bg-yellow-50 border border-yellow-200 rounded-md p-4">
            <div class="flex">
              <div class="flex-shrink-0">
                <svg class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                  <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
                </svg>
              </div>
              <div class="ml-3">
                <h3 class="text-sm font-medium text-yellow-800">Enrollment Closed</h3>
                <p class="mt-2 text-sm text-yellow-700">Enrollment is currently closed. Please wait for the enrollment period to open.</p>
              </div>
            </div>
          </div>

          <!-- Current Enrollment Display -->
          <div v-else-if="student.isEnrolled" class="bg-white shadow overflow-hidden sm:rounded-lg">
            <div class="px-4 py-5 sm:px-6 bg-green-50">
              <h3 class="text-lg leading-6 font-medium text-green-900">Registration Form</h3>
              <p class="mt-1 max-w-2xl text-sm text-green-700">Your current enrollment details for {{ systemSettings.current_school_year }}</p>
              <div class="mt-2">
                <span :class="[
                  student.currentEnrollment.status === 'approved' ? 'bg-green-100 text-green-800' :
                  student.currentEnrollment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800',
                  'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium'
                ]">
                  {{ student.currentEnrollment.status.toUpperCase() }}
                </span>
              </div>
            </div>
            <div class="border-t border-gray-200">
              <dl>
                <div class="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                  <dt class="text-sm font-medium text-gray-500">Student Information</dt>
                  <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                    <div class="grid grid-cols-2 gap-4">
                      <div>
                        <p><strong>Name:</strong> {{ student.first_name }} {{ student.last_name }}</p>
                        <p><strong>Student ID:</strong> {{ student.student_id }}</p>
                        <p><strong>Course:</strong> {{ user.course }}</p>
                      </div>
                      <div>
                        <p><strong>Year Level:</strong> {{ getOrdinalYear(student.year_level) }}</p>
                        <p><strong>Semester:</strong> {{ getOrdinalSemester(systemSettings.current_semester) }}</p>
                        <p><strong>School Year:</strong> {{ systemSettings.current_school_year }}</p>
                      </div>
                    </div>
                  </dd>
                </div>
                
                <div class="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                  <dt class="text-sm font-medium text-gray-500">Schedule</dt>
                  <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                    <div class="overflow-x-auto">
                      <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                          <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject Code</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject Name</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Days</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Room</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Units</th>
                          </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                          <tr v-for="subject in student.enrolledSubjects" :key="subject.subject_code">
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{{ subject.subject_code }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ subject.subject_name }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ formatTime(subject.time_start) }} - {{ formatTime(subject.time_end) }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ subject.days }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ subject.room_name || 'TBA' }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ subject.units }}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </dd>
                </div>
                
                <div class="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                  <dt class="text-sm font-medium text-gray-500">Financial Summary</dt>
                  <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                    <div class="grid grid-cols-2 gap-4">
                      <div>
                        <p><strong>Total Units:</strong> {{ student.currentEnrollment.total_units }}</p>
                        <p><strong>Tuition Fee:</strong> ₱{{ formatCurrency(student.currentEnrollment.tuition_fee) }}</p>
                        <p><strong>Laboratory Fee:</strong> ₱{{ formatCurrency(student.currentEnrollment.lab_fee) }}</p>
                      </div>
                      <div>
                        <p><strong>Miscellaneous Fee:</strong> ₱{{ formatCurrency(student.currentEnrollment.misc_fee) }}</p>
                        <p><strong>Other Fees:</strong> ₱{{ formatCurrency(student.currentEnrollment.other_fees || 0) }}</p>
                        <p class="text-lg font-bold text-blue-600"><strong>Total Fee:</strong> ₱{{ formatCurrency(student.currentEnrollment.total_fee) }}</p>
                      </div>
                    </div>
                  </dd>
                </div>
              </dl>
            </div>
          </div>

          <!-- Available Sections -->
          <div v-else class="space-y-6">
            <div class="bg-white shadow sm:rounded-lg">
              <div class="px-4 py-5 sm:p-6">
                <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Available Sections</h3>
                <p class="text-sm text-gray-600 mb-6">Select a section to enroll for {{ systemSettings.current_school_year }} - {{ getOrdinalSemester(systemSettings.current_semester) }} Semester</p>
                
                <div v-if="loadingSections" class="flex justify-center py-8">
                  <svg class="animate-spin h-8 w-8 text-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                </div>
                
                <div v-else-if="availableSections.length === 0" class="text-center py-8 text-gray-500">
                  <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  <p class="mt-2 text-sm">No sections available for your course and year level.</p>
                </div>
                
                <div v-else class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  <div
                    v-for="section in availableSections"
                    :key="section.id"
                    class="relative rounded-lg border border-gray-300 bg-white px-6 py-5 shadow-sm hover:border-gray-400 cursor-pointer transition-colors"
                    :class="{ 'opacity-50 cursor-not-allowed': section.available_slots <= 0 }"
                    @click="selectSection(section)"
                  >
                    <div class="flex justify-between items-start mb-3">
                      <div class="flex-1">
                        <h4 class="text-lg font-medium text-gray-900">{{ section.section_name }}</h4>
                        <p class="text-sm text-gray-500 capitalize">{{ section.schedule_type }} Schedule</p>
                        <p class="text-sm text-gray-500">{{ section.timeSlot }}</p>
                      </div>
                      <span :class="[
                        section.available_slots > 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800',
                        'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium'
                      ]">
                        {{ section.available_slots > 0 ? 'Available' : 'Full' }}
                      </span>
                    </div>
                    
                    <div class="text-sm text-gray-600 mb-3">
                      <p>Slots: {{ section.available_slots }}/{{ section.max_capacity }}</p>
                      <p>Total Units: {{ section.totalUnits }}</p>
                      <p>Total Fee: ₱{{ formatCurrency(section.totalFee) }}</p>
                    </div>
                    
                    <div class="text-xs text-gray-500">
                      <p>{{ section.subjects.length }} subjects</p>
                      <p v-if="section.adviser_name">Adviser: {{ section.adviser_name }}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Accountabilities Tab -->
        <div v-if="activeTab === 'accountabilities'" class="space-y-6">
          <div class="bg-white shadow overflow-hidden sm:rounded-lg">
            <div class="px-4 py-5 sm:px-6">
              <h3 class="text-lg leading-6 font-medium text-gray-900">Account Status</h3>
              <p class="mt-1 max-w-2xl text-sm text-gray-500">Your current accountabilities and requirements</p>
            </div>
            <div class="border-t border-gray-200">
              <!-- Financial Accountabilities -->
              <div class="px-4 py-5 sm:px-6">
                <h4 class="text-md font-medium text-gray-900 mb-4 flex items-center">
                  <svg class="h-5 w-5 mr-2 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                  </svg>
                  Financial Accountabilities
                </h4>
                <div v-if="student.financialAccountabilities.length === 0" class="text-green-600 flex items-center">
                  <svg class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                  </svg>
                  No pending financial obligations
                </div>
                <div v-else class="space-y-3">
                  <div
                    v-for="item in student.financialAccountabilities"
                    :key="item.id"
                    class="flex justify-between items-center p-4 bg-red-50 rounded-lg border border-red-200"
                  >
                    <div class="flex-1">
                      <p class="font-medium text-red-800">{{ item.description }}</p>
                      <p class="text-sm text-red-600">Due: {{ formatDate(item.due_date) }}</p>
                      <p v-if="item.notes" class="text-sm text-red-600 mt-1">{{ item.notes }}</p>
                    </div>
                    <div class="text-right">
                      <span class="text-red-800 font-bold text-lg">₱{{ formatCurrency(item.amount) }}</span>
                      <div class="text-xs text-red-600 mt-1">
                        {{ getDaysOverdue(item.due_date) }}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Document Requirements -->
              <div class="px-4 py-5 sm:px-6 border-t border-gray-200">
                <h4 class="text-md font-medium text-gray-900 mb-4 flex items-center">
                  <svg class="h-5 w-5 mr-2 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  Document Requirements
                </h4>
                <div v-if="student.documentRequirements.length === 0" class="text-green-600 flex items-center">
                  <svg class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                  </svg>
                  All required documents submitted
                </div>
                <div v-else class="space-y-3">
                  <div
                    v-for="doc in student.documentRequirements"
                    :key="doc.id"
                    :class="[
                      doc.status === 'pending' ? 'bg-yellow-50 border-yellow-200' :
                      doc.status === 'submitted' ? 'bg-blue-50 border-blue-200' :
                      doc.status === 'rejected' ? 'bg-red-50 border-red-200' :
                      'bg-gray-50 border-gray-200',
                      'flex justify-between items-center p-4 rounded-lg border'
                    ]"
                  >
                    <div class="flex-1">
                      <p :class="[
                        doc.status === 'pending' ? 'text-yellow-800' :
                        doc.status === 'submitted' ? 'text-blue-800' :
                        doc.status === 'rejected' ? 'text-red-800' :
                        'text-gray-800',
                        'font-medium'
                      ]">{{ doc.document_name }}</p>
                      <p v-if="doc.description" :class="[
                        doc.status === 'pending' ? 'text-yellow-600' :
                        doc.status === 'submitted' ? 'text-blue-600' :
                        doc.status === 'rejected' ? 'text-red-600' :
                        'text-gray-600',
                        'text-sm'
                      ]">{{ doc.description }}</p>
                      <p v-if="doc.due_date" :class="[
                        doc.status === 'pending' ? 'text-yellow-600' :
                        doc.status === 'submitted' ? 'text-blue-600' :
                        doc.status === 'rejected' ? 'text-red-600' :
                        'text-gray-600',
                        'text-sm'
                      ]">Due: {{ formatDate(doc.due_date) }}</p>
                      <p v-if="doc.rejection_reason" class="text-sm text-red-600 mt-1">
                        <strong>Rejection Reason:</strong> {{ doc.rejection_reason }}
                      </p>
                    </div>
                    <div class="flex flex-col items-end space-y-2">
                      <span :class="[
                        doc.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        doc.status === 'submitted' ? 'bg-blue-100 text-blue-800' :
                        doc.status === 'verified' ? 'bg-green-100 text-green-800' :
                        doc.status === 'rejected' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800',
                        'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium'
                      ]">
                        {{ doc.status.toUpperCase() }}
                      </span>
                      <div v-if="doc.status === 'pending' || doc.status === 'rejected'" class="flex space-x-2">
                        <input
                          type="file"
                          :id="'file-' + doc.id"
                          @change="handleFileUpload($event, doc.id)"
                          accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                          class="hidden"
                        />
                        <button
                          @click="document.getElementById('file-' + doc.id).click()"
                          class="text-xs bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700"
                        >
                          Upload
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Grades Tab -->
        <div v-if="activeTab === 'grades'" class="space-y-6">
          <div class="bg-white shadow sm:rounded-lg">
            <div class="px-4 py-5 sm:p-6">
              <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Grade Viewing</h3>
              
              <!-- Semester/Year Filter -->
              <div class="mb-6 flex flex-wrap gap-4">
                <div class="flex-1 min-w-48">
                  <label for="schoolYear" class="block text-sm font-medium text-gray-700">School Year</label>
                  <select
                    id="schoolYear"
                    v-model="selectedSchoolYear"
                    class="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                  >
                    <option v-for="year in availableSchoolYears" :key="year" :value="year">{{ year }}</option>
                  </select>
                </div>
                <div class="flex-1 min-w-48">
                  <label for="semester" class="block text-sm font-medium text-gray-700">Semester</label>
                  <select
                    id="semester"
                    v-model="selectedSemester"
                    class="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                  >
                    <option value="1">1st Semester</option>
                    <option value="2">2nd Semester</option>
                  </select>
                </div>
                <div class="flex items-end">
                  <button
                    @click="loadGrades"
                    :disabled="loadingGrades"
                    class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium disabled:opacity-50 flex items-center"
                  >
                    <svg v-if="loadingGrades" class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                      <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    {{ loadingGrades ? 'Loading...' : 'Load Grades' }}
                  </button>
                </div>
              </div>

              <!-- Grades Table -->
              <div v-if="selectedGrades.length > 0" class="space-y-4">
                <div class="overflow-x-auto">
                  <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                      <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject Code</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Units</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Midterm</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Final</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rating</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Remarks</th>
                      </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                      <tr v-for="grade in selectedGrades" :key="grade.id">
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{{ grade.subject_code }}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ grade.subject_name }}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ grade.units }}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ grade.midterm_grade || 'N/A' }}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ grade.final_grade || 'N/A' }}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{{ grade.final_rating || 'N/A' }}</td>
                        <td class="px-6 py-4 whitespace-nowrap">
                          <span :class="[
                            grade.remarks === 'PASSED' ? 'bg-green-100 text-green-800' : 
                            grade.remarks === 'FAILED' ? 'bg-red-100 text-red-800' :
                            grade.remarks === 'INC' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-gray-100 text-gray-800',
                            'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium'
                          ]">
                            {{ grade.remarks }}
                          </span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                
                <!-- GPA Summary -->
                <div class="bg-gray-50 p-4 rounded-lg">
                  <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div class="text-center">
                      <div class="text-2xl font-bold text-blue-600">{{ calculateGPA(selectedGrades) }}</div>
                      <div class="text-sm text-gray-600">Semester GPA</div>
                    </div>
                    <div class="text-center">
                      <div class="text-2xl font-bold text-green-600">{{ getTotalUnits(selectedGrades) }}</div>
                      <div class="text-sm text-gray-600">Total Units</div>
                    </div>
                    <div class="text-center">
                      <div class="text-2xl font-bold text-purple-600">{{ getPassedUnits(selectedGrades) }}</div>
                      <div class="text-sm text-gray-600">Passed Units</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div v-else-if="gradesLoaded && selectedGrades.length === 0" class="text-center py-8 text-gray-500">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <p class="mt-2 text-sm">No grades found for the selected period.</p>
              </div>
              
              <div v-else-if="!gradesLoaded" class="text-center py-8 text-gray-500">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
                <p class="mt-2 text-sm">Select a school year and semester to view grades.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Admin Dashboard -->
      <div v-else-if="user.role === 'admin'" class="px-4 py-6 sm:px-0">
        <!-- Dashboard Header -->
        <div class="mb-8">
          <h1 class="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p class="mt-2 text-gray-600">Manage enrollment, students, and system settings</p>
        </div>

        <!-- Quick Stats -->
        <div class="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
          <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
              <div class="flex items-center">
                <div class="flex-shrink-0">
                  <svg class="h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
                  </svg>
                </div>
                <div class="ml-5 w-0 flex-1">
                  <dl>
                    <dt class="text-sm font-medium text-gray-500 truncate">Total Students</dt>
                    <dd class="text-lg font-medium text-gray-900">{{ adminStats.total_students || 0 }}</dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>

          <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
              <div class="flex items-center">
                <div class="flex-shrink-0">
                  <svg class="h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <div class="ml-5 w-0 flex-1">
                  <dl>
                    <dt class="text-sm font-medium text-gray-500 truncate">Enrolled This Semester</dt>
                    <dd class="text-lg font-medium text-gray-900">{{ adminStats.total_enrolled || 0 }}</dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>

          <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
              <div class="flex items-center">
                <div class="flex-shrink-0">
                  <svg class="h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v3m0 0v
