"use client"

import  from "../ecosystem.config"

export default function SyntheticV0PageForDeployment() {
  return < />
}