#!/bin/bash

echo "🚀 Setting up NCST Enrollment System..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 16 or higher."
    exit 1
fi

# Check if MySQL is installed
if ! command -v mysql &> /dev/null; then
    echo "❌ MySQL is not installed. Please install MySQL 8.0 or higher."
    exit 1
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Create environment file if it doesn't exist
if [ ! -f .env ]; then
    echo "📝 Creating environment file..."
    cp .env.example .env
    echo "⚠️  Please update the .env file with your database credentials!"
fi

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p uploads
mkdir -p logs

# Set permissions
chmod 755 uploads
chmod 755 logs

echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "1. Update your .env file with database credentials"
echo "2. Create MySQL database: CREATE DATABASE ncst_enrollment;"
echo "3. Import database schema: mysql -u root -p ncst_enrollment < database/schema.sql"
echo "4. Start the server: npm start"
echo "5. Open http://localhost:3000 in your browser"
echo ""
echo "Default login credentials:"
echo "Admin: admin / admin"
echo "Student: 2021-001234 / Doe"
