-- NCST Enrollment System Database Schema
CREATE DATABASE IF NOT EXISTS ncst_enrollment;
USE ncst_enrollment;

-- Drop existing tables if they exist (for development)
DROP TABLE IF EXISTS enrollment_subjects;
DROP TABLE IF EXISTS student_grades;
DROP TABLE IF EXISTS document_requirements;
DROP TABLE IF EXISTS financial_accountabilities;
DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS section_subjects;
DROP TABLE IF EXISTS sections;
DROP TABLE IF EXISTS subjects;
DROP TABLE IF EXISTS rooms;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS system_settings;
DROP TABLE IF EXISTS audit_logs;

-- Users table (for authentication)
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('student', 'admin', 'registrar') NOT NULL DEFAULT 'student',
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_role (role)
);

-- Courses table
CREATE TABLE courses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    course_code VARCHAR(10) UNIQUE NOT NULL,
    course_name VARCHAR(100) NOT NULL,
    department VARCHAR(50) NOT NULL,
    total_units INT NOT NULL,
    years_to_complete INT DEFAULT 4,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_course_code (course_code),
    INDEX idx_department (department)
);

-- Students table
CREATE TABLE students (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id VARCHAR(20) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    email VARCHAR(100),
    phone VARCHAR(20),
    address TEXT,
    birth_date DATE,
    gender ENUM('Male', 'Female', 'Other'),
    course_id INT NOT NULL,
    year_level INT NOT NULL,
    status ENUM('active', 'inactive', 'graduated', 'dropped') DEFAULT 'active',
    date_enrolled DATE,
    guardian_name VARCHAR(100),
    guardian_phone VARCHAR(20),
    emergency_contact VARCHAR(100),
    emergency_phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE RESTRICT,
    INDEX idx_student_id (student_id),
    INDEX idx_course_year (course_id, year_level),
    INDEX idx_status (status)
);

-- Subjects table
CREATE TABLE subjects (
    id INT PRIMARY KEY AUTO_INCREMENT,
    subject_code VARCHAR(20) UNIQUE NOT NULL,
    subject_name VARCHAR(100) NOT NULL,
    description TEXT,
    units INT NOT NULL,
    lecture_hours INT DEFAULT 0,
    lab_hours INT DEFAULT 0,
    course_id INT,
    year_level INT NOT NULL,
    semester INT NOT NULL,
    is_elective BOOLEAN DEFAULT FALSE,
    prerequisites TEXT, -- JSON array of prerequisite subject IDs
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE SET NULL,
    INDEX idx_subject_code (subject_code),
    INDEX idx_course_year_sem (course_id, year_level, semester)
);

-- Rooms table
CREATE TABLE rooms (
    id INT PRIMARY KEY AUTO_INCREMENT,
    room_code VARCHAR(20) UNIQUE NOT NULL,
    room_name VARCHAR(50) NOT NULL,
    capacity INT NOT NULL,
    room_type ENUM('classroom', 'laboratory', 'auditorium', 'gym') NOT NULL,
    building VARCHAR(50),
    floor INT,
    facilities TEXT, -- JSON array of available facilities
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_room_code (room_code),
    INDEX idx_room_type (room_type)
);

-- Sections table
CREATE TABLE sections (
    id INT PRIMARY KEY AUTO_INCREMENT,
    section_code VARCHAR(20) UNIQUE NOT NULL,
    section_name VARCHAR(50) NOT NULL,
    course_id INT NOT NULL,
    year_level INT NOT NULL,
    semester INT NOT NULL,
    school_year VARCHAR(20) NOT NULL,
    max_capacity INT NOT NULL,
    current_enrolled INT DEFAULT 0,
    schedule_type ENUM('morning', 'afternoon', 'evening') NOT NULL,
    status ENUM('open', 'closed', 'full', 'cancelled') DEFAULT 'open',
    start_time TIME,
    end_time TIME,
    adviser_name VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE RESTRICT,
    INDEX idx_section_code (section_code),
    INDEX idx_course_year_sem (course_id, year_level, semester, school_year),
    INDEX idx_status (status)
);

-- Section Subjects (subjects offered in each section with schedule)
CREATE TABLE section_subjects (
    id INT PRIMARY KEY AUTO_INCREMENT,
    section_id INT NOT NULL,
    subject_id INT NOT NULL,
    room_id INT,
    instructor_name VARCHAR(100),
    instructor_email VARCHAR(100),
    time_start TIME NOT NULL,
    time_end TIME NOT NULL,
    days VARCHAR(20) NOT NULL, -- e.g., 'MWF', 'TTH', 'MTWTHF'
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (section_id) REFERENCES sections(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE RESTRICT,
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE SET NULL,
    UNIQUE KEY unique_section_subject (section_id, subject_id),
    INDEX idx_section_schedule (section_id, days, time_start, time_end),
    INDEX idx_room_schedule (room_id, days, time_start, time_end)
);

-- Enrollments table
CREATE TABLE enrollments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    section_id INT NOT NULL,
    school_year VARCHAR(20) NOT NULL,
    semester INT NOT NULL,
    enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending', 'approved', 'rejected', 'dropped', 'cancelled') DEFAULT 'pending',
    total_units INT,
    tuition_fee DECIMAL(10,2),
    misc_fee DECIMAL(10,2),
    lab_fee DECIMAL(10,2) DEFAULT 0,
    other_fees DECIMAL(10,2) DEFAULT 0,
    total_fee DECIMAL(10,2),
    payment_status ENUM('unpaid', 'partial', 'paid') DEFAULT 'unpaid',
    approved_by INT NULL,
    approved_at TIMESTAMP NULL,
    rejection_reason TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (section_id) REFERENCES sections(id) ON DELETE RESTRICT,
    FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY unique_student_semester (student_id, school_year, semester),
    INDEX idx_status (status),
    INDEX idx_school_year_semester (school_year, semester)
);

-- Enrollment Subjects (individual subjects in an enrollment)
CREATE TABLE enrollment_subjects (
    id INT PRIMARY KEY AUTO_INCREMENT,
    enrollment_id INT NOT NULL,
    section_subject_id INT NOT NULL,
    status ENUM('enrolled', 'dropped', 'completed') DEFAULT 'enrolled',
    dropped_date TIMESTAMP NULL,
    drop_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (enrollment_id) REFERENCES enrollments(id) ON DELETE CASCADE,
    FOREIGN KEY (section_subject_id) REFERENCES section_subjects(id) ON DELETE RESTRICT,
    UNIQUE KEY unique_enrollment_subject (enrollment_id, section_subject_id)
);

-- Student Grades table
CREATE TABLE student_grades (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    subject_id INT NOT NULL,
    enrollment_id INT,
    school_year VARCHAR(20) NOT NULL,
    semester INT NOT NULL,
    midterm_grade DECIMAL(3,2),
    final_grade DECIMAL(3,2),
    final_rating DECIMAL(3,2),
    remarks ENUM('PASSED', 'FAILED', 'INC', 'DRP', 'W') DEFAULT 'PASSED',
    instructor_name VARCHAR(100),
    date_recorded TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    recorded_by INT,
    is_final BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE RESTRICT,
    FOREIGN KEY (enrollment_id) REFERENCES enrollments(id) ON DELETE SET NULL,
    FOREIGN KEY (recorded_by) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY unique_student_subject_term (student_id, subject_id, school_year, semester),
    INDEX idx_student_term (student_id, school_year, semester)
);

-- Financial Accountabilities table
CREATE TABLE financial_accountabilities (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    description VARCHAR(255) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    due_date DATE,
    status ENUM('pending', 'paid', 'overdue', 'waived') DEFAULT 'pending',
    payment_date TIMESTAMP NULL,
    payment_method VARCHAR(50),
    reference_number VARCHAR(100),
    created_by INT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_student_status (student_id, status),
    INDEX idx_due_date (due_date)
);

-- Document Requirements table
CREATE TABLE document_requirements (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    document_name VARCHAR(100) NOT NULL,
    description TEXT,
    status ENUM('pending', 'submitted', 'verified', 'rejected', 'expired') DEFAULT 'pending',
    due_date DATE,
    submitted_date TIMESTAMP NULL,
    verified_date TIMESTAMP NULL,
    verified_by INT,
    file_path VARCHAR(255),
    rejection_reason TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_student_status (student_id, status),
    INDEX idx_due_date (due_date)
);

-- System Settings table
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(50) UNIQUE NOT NULL,
    setting_value TEXT,
    data_type ENUM('string', 'number', 'boolean', 'json') DEFAULT 'string',
    description TEXT,
    is_public BOOLEAN DEFAULT FALSE,
    updated_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_setting_key (setting_key)
);

-- Audit Logs table
CREATE TABLE audit_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(50),
    record_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user_action (user_id, action),
    INDEX idx_table_record (table_name, record_id),
    INDEX idx_created_at (created_at)
);

-- Insert initial system settings
INSERT INTO system_settings (setting_key, setting_value, data_type, description, is_public) VALUES
('enrollment_status', 'open', 'string', 'Current enrollment status (open/closed)', TRUE),
('current_school_year', '2024-2025', 'string', 'Current school year', TRUE),
('current_semester', '1', 'number', 'Current semester (1 or 2)', TRUE),
('tuition_per_unit', '1200', 'number', 'Tuition fee per unit', FALSE),
('misc_fee', '5000', 'number', 'Miscellaneous fee per semester', FALSE),
('lab_fee_per_unit', '500', 'number', 'Laboratory fee per unit', FALSE),
('late_enrollment_fee', '500', 'number', 'Late enrollment penalty fee', FALSE),
('max_units_per_semester', '24', 'number', 'Maximum units per semester', TRUE),
('min_units_per_semester', '12', 'number', 'Minimum units per semester', TRUE),
('enrollment_deadline', '2024-08-15', 'string', 'Enrollment deadline', TRUE),
('grade_release_date', '2024-12-15', 'string', 'Grade release date', TRUE),
('system_maintenance', 'false', 'boolean', 'System maintenance mode', TRUE);

-- Insert sample courses
INSERT INTO courses (course_code, course_name, department, total_units, years_to_complete) VALUES
('BSCS', 'Bachelor of Science in Computer Science', 'Computer Science', 120, 4),
('BSIT', 'Bachelor of Science in Information Technology', 'Information Technology', 120, 4),
('BSCE', 'Bachelor of Science in Computer Engineering', 'Computer Engineering', 130, 4),
('BSEE', 'Bachelor of Science in Electrical Engineering', 'Electrical Engineering', 130, 4),
('BSME', 'Bachelor of Science in Mechanical Engineering', 'Mechanical Engineering', 130, 4);

-- Insert sample rooms
INSERT INTO rooms (room_code, room_name, capacity, room_type, building, floor, facilities) VALUES
('CS-LAB1', 'Computer Science Laboratory 1', 40, 'laboratory', 'IT Building', 2, '["computers", "projector", "air_conditioning"]'),
('CS-LAB2', 'Computer Science Laboratory 2', 40, 'laboratory', 'IT Building', 2, '["computers", "projector", "air_conditioning"]'),
('CS-LAB3', 'Computer Science Laboratory 3', 40, 'laboratory', 'IT Building', 3, '["computers", "projector", "air_conditioning"]'),
('CS-LAB4', 'Computer Science Laboratory 4', 40, 'laboratory', 'IT Building', 3, '["computers", "projector", "air_conditioning"]'),
('ROOM-201', 'Room 201', 45, 'classroom', 'Main Building', 2, '["projector", "whiteboard", "air_conditioning"]'),
('ROOM-202', 'Room 202', 45, 'classroom', 'Main Building', 2, '["projector", "whiteboard", "air_conditioning"]'),
('ROOM-301', 'Room 301', 50, 'classroom', 'Main Building', 3, '["projector", "whiteboard", "air_conditioning"]'),
('ROOM-302', 'Room 302', 50, 'classroom', 'Main Building', 3, '["projector", "whiteboard", "air_conditioning"]'),
('EE-LAB1', 'Electrical Engineering Lab 1', 30, 'laboratory', 'Engineering Building', 1, '["equipment", "safety_gear", "projector"]'),
('ME-LAB1', 'Mechanical Engineering Lab 1', 25, 'laboratory', 'Engineering Building', 1, '["machinery", "tools", "safety_gear"]');

-- Insert sample subjects for Computer Science
INSERT INTO subjects (subject_code, subject_name, description, units, lecture_hours, lab_hours, course_id, year_level, semester, prerequisites) VALUES
-- 1st Year, 1st Semester
('CS101', 'Introduction to Computing', 'Basic concepts of computing and programming', 3, 2, 3, 1, 1, 1, '[]'),
('MATH101', 'College Algebra', 'Fundamental algebraic concepts', 3, 3, 0, 1, 1, 1, '[]'),
('ENG101', 'English Communication', 'Basic English communication skills', 3, 3, 0, 1, 1, 1, '[]'),
('PE101', 'Physical Education 1', 'Basic physical fitness', 2, 0, 6, 1, 1, 1, '[]'),
('NSTP101', 'National Service Training Program 1', 'Civic welfare training', 3, 3, 0, 1, 1, 1, '[]'),
('SCI101', 'General Chemistry', 'Basic chemistry concepts', 3, 2, 3, 1, 1, 1, '[]'),

-- 1st Year, 2nd Semester
('CS102', 'Programming Fundamentals', 'Basic programming concepts', 3, 2, 3, 1, 1, 2, '[1]'),
('MATH102', 'Trigonometry', 'Trigonometric functions and applications', 3, 3, 0, 1, 1, 2, '[2]'),
('ENG102', 'Speech Communication', 'Oral communication skills', 3, 3, 0, 1, 1, 2, '[3]'),
('PE102', 'Physical Education 2', 'Intermediate physical fitness', 2, 0, 6, 1, 1, 2, '[4]'),
('NSTP102', 'National Service Training Program 2', 'Community service', 3, 3, 0, 1, 1, 2, '[5]'),
('SCI102', 'General Physics', 'Basic physics concepts', 3, 2, 3, 1, 1, 2, '[6]'),

-- 2nd Year, 1st Semester
('CS201', 'Object-Oriented Programming', 'OOP concepts and implementation', 3, 2, 3, 1, 2, 1, '[7]'),
('CS202', 'Discrete Mathematics', 'Mathematical foundations for CS', 3, 3, 0, 1, 2, 1, '[8]'),
('CS203', 'Computer Organization', 'Computer hardware and architecture', 3, 2, 3, 1, 2, 1, '[1]'),
('MATH201', 'Calculus I', 'Differential calculus', 3, 3, 0, 1, 2, 1, '[8]'),
('PHYS201', 'Physics for Engineers', 'Applied physics concepts', 3, 2, 3, 1, 2, 1, '[12]'),
('HUM201', 'Philippine History', 'History of the Philippines', 3, 3, 0, 1, 2, 1, '[]'),

-- 2nd Year, 2nd Semester
('CS204', 'Data Structures', 'Data organization and algorithms', 3, 2, 3, 1, 2, 2, '[13]'),
('CS205', 'Systems Analysis and Design', 'System development methodologies', 3, 3, 0, 1, 2, 2, '[13]'),
('CS206', 'Human-Computer Interaction', 'User interface design principles', 3, 2, 3, 1, 2, 2, '[13]'),
('MATH202', 'Calculus II', 'Integral calculus', 3, 3, 0, 1, 2, 2, '[16]'),
('STAT201', 'Statistics and Probability', 'Statistical analysis methods', 3, 3, 0, 1, 2, 2, '[16]'),
('HUM202', 'Ethics', 'Moral philosophy and professional ethics', 3, 3, 0, 1, 2, 2, '[]'),

-- 3rd Year, 1st Semester
('CS301', 'Data Structures and Algorithms', 'Advanced data structures and algorithms', 3, 2, 3, 1, 3, 1, '[19]'),
('CS302', 'Database Management Systems', 'Database design and implementation', 3, 2, 3, 1, 3, 1, '[19]'),
('CS303', 'Software Engineering', 'Software development methodologies', 3, 3, 0, 1, 3, 1, '[20]'),
('CS304', 'Computer Networks', 'Network protocols and architecture', 3, 2, 3, 1, 3, 1, '[15]'),
('CS305', 'Web Development', 'Web application development', 3, 2, 3, 1, 3, 1, '[19]'),
('MATH301', 'Linear Algebra', 'Matrix operations and vector spaces', 3, 3, 0, 1, 3, 1, '[22]'),
('ENG301', 'Technical Writing', 'Technical documentation skills', 3, 3, 0, 1, 3, 1, '[10]'),

-- 3rd Year, 2nd Semester
('CS306', 'Operating Systems', 'OS concepts and implementation', 3, 2, 3, 1, 3, 2, '[25]'),
('CS307', 'Computer Graphics', 'Graphics programming and visualization', 3, 2, 3, 1, 3, 2, '[25]'),
('CS308', 'Mobile Application Development', 'Mobile app development', 3, 2, 3, 1, 3, 2, '[27]'),
('CS309', 'Machine Learning', 'ML algorithms and applications', 3, 2, 3, 1, 3, 2, '[28]'),
('CS310', 'Information Security', 'Cybersecurity principles', 3, 2, 3, 1, 3, 2, '[26]'),
('MATH302', 'Numerical Methods', 'Computational mathematics', 3, 2, 3, 1, 3, 2, '[28]');

-- Create admin user (password: admin123)
INSERT INTO users (username, password, role) VALUES
('admin', '$2b$10$rOzWz8VJkKKvKVqKVqKVqOzWz8VJkKKvKVqKVqKVqOzWz8VJkKKvK', 'admin');

-- Create sample students
INSERT INTO students (student_id, first_name, last_name, middle_name, email, phone, course_id, year_level, date_enrolled, status) VALUES
('2021-001234', 'John', 'Doe', 'Smith', 'john.doe@ncst.edu.ph', '09123456789', 1, 3, '2021-08-15', 'active'),
('2021-001235', 'Maria', 'Santos', 'Cruz', 'maria.santos@ncst.edu.ph', '09123456790', 1, 3, '2021-08-15', 'active'),
('2021-001236', 'Juan', 'Dela Cruz', 'Reyes', 'juan.delacruz@ncst.edu.ph', '09123456791', 2, 2, '2021-08-15', 'active'),
('2022-001237', 'Ana', 'Rodriguez', 'Garcia', 'ana.rodriguez@ncst.edu.ph', '09123456792', 1, 2, '2022-08-15', 'active'),
('2020-001238', 'Pedro', 'Gonzales', 'Martinez', 'pedro.gonzales@ncst.edu.ph', '09123456793', 3, 4, '2020-08-15', 'active');

-- Create user accounts for students (password: lastname in lowercase)
INSERT INTO users (username, password, role) VALUES
('2021-001234', '$2b$10$rOzWz8VJkKKvKVqKVqKVqOzWz8VJkKKvKVqKVqKVqOzWz8VJkKKvK', 'student'), -- doe
('2021-001235', '$2b$10$rOzWz8VJkKKvKVqKVqKVqOzWz8VJkKKvKVqKVqKVqOzWz8VJkKKvK', 'student'), -- santos
('2021-001236', '$2b$10$rOzWz8VJkKKvKVqKVqKVqOzWz8VJkKKvKVqKVqKVqOzWz8VJkKKvK', 'student'), -- delacruz
('2022-001237', '$2b$10$rOzWz8VJkKKvKVqKVqKVqOzWz8VJkKKvKVqKVqOzWz8VJkKKvK', 'student'), -- rodriguez
('2020-001238', '$2b$10$rOzWz8VJkKKvKVqKVqKVqOzWz8VJkKKvKVqKVqKVqOzWz8VJkKKvK', 'student'); -- gonzales
