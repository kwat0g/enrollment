const express = require("express")
const cors = require("cors")
const mysql = require("mysql2/promise")
const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")
const dotenv = require("dotenv")
const multer = require("multer")
const path = require("path")
const fs = require("fs")

dotenv.config()

const app = express()
const PORT = process.env.PORT || 3000

// Middleware
app.use(
  cors({
    origin: process.env.FRONTEND_URL || "http://localhost:8080",
    credentials: true,
  }),
)
app.use(express.json({ limit: "10mb" }))
app.use(express.urlencoded({ extended: true, limit: "10mb" }))

// Static files for uploads
app.use("/uploads", express.static("uploads"))

// Create uploads directory if it doesn't exist
if (!fs.existsSync("uploads")) {
  fs.mkdirSync("uploads")
}

// Database connection pool
const dbPool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "ncst_enrollment",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  acquireTimeout: 60000,
  timeout: 60000,
})

// File upload configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = `uploads/${req.user.username}`
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true })
    }
    cb(null, uploadPath)
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9)
    cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname))
  },
})

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|pdf|doc|docx/
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase())
    const mimetype = allowedTypes.test(file.mimetype)

    if (mimetype && extname) {
      return cb(null, true)
    } else {
      cb(new Error("Only images and documents are allowed"))
    }
  },
})

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  if (!token) {
    return res.status(401).json({ error: "Access token required" })
  }

  jwt.verify(token, process.env.JWT_SECRET || "ncst-secret-key-2024", (err, user) => {
    if (err) {
      return res.status(403).json({ error: "Invalid or expired token" })
    }
    req.user = user
    next()
  })
}

// Middleware to check if user is admin
const requireAdmin = (req, res, next) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Admin access required" })
  }
  next()
}

// Audit logging function
const logAudit = async (userId, action, tableName, recordId, oldValues, newValues, req) => {
  try {
    await dbPool.execute(
      `INSERT INTO audit_logs (user_id, action, table_name, record_id, old_values, new_values, ip_address, user_agent) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        userId,
        action,
        tableName,
        recordId,
        oldValues ? JSON.stringify(oldValues) : null,
        newValues ? JSON.stringify(newValues) : null,
        req.ip,
        req.get("User-Agent"),
      ],
    )
  } catch (error) {
    console.error("Audit log error:", error)
  }
}

// AUTHENTICATION ROUTES
app.post("/api/auth/login", async (req, res) => {
  try {
    const { studentId, lastname } = req.body

    if (!studentId || !lastname) {
      return res.status(400).json({ error: "Student ID and lastname are required" })
    }

    // Check if user exists and get student info
    const [users] = await dbPool.execute(
      `SELECT u.*, s.first_name, s.last_name, s.middle_name, s.course_id, s.year_level, s.status, c.course_name
       FROM users u 
       LEFT JOIN students s ON u.username = s.student_id 
       LEFT JOIN courses c ON s.course_id = c.id
       WHERE u.username = ? AND u.is_active = TRUE`,
      [studentId],
    )

    if (users.length === 0) {
      return res.status(401).json({ error: "Invalid credentials or account not found" })
    }

    const user = users[0]

    // For students, verify lastname and eligibility
    if (user.role === "student") {
      if (!user.last_name || user.last_name.toLowerCase() !== lastname.toLowerCase()) {
        return res.status(401).json({ error: "Invalid credentials" })
      }

      // Check if student is eligible (2nd year or higher)
      if (user.year_level < 2) {
        return res.status(403).json({
          error: "Only 2nd year students and above can access online enrollment",
        })
      }

      if (user.status !== "active") {
        return res.status(403).json({
          error: "Account is not active. Please contact the registrar.",
        })
      }
    }

    // Update last login
    await dbPool.execute("UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?", [user.id])

    // Generate JWT token
    const token = jwt.sign(
      {
        id: user.id,
        username: user.username,
        role: user.role,
        studentId: user.username,
      },
      process.env.JWT_SECRET || "ncst-secret-key-2024",
      { expiresIn: "24h" },
    )

    // Log audit
    await logAudit(user.id, "LOGIN", "users", user.id, null, null, req)

    res.json({
      token,
      user: {
        id: user.id,
        name: user.role === "admin" ? "System Administrator" : `${user.first_name} ${user.last_name}`,
        role: user.role,
        studentId: user.username,
        course: user.course_name,
        yearLevel: user.year_level,
      },
    })
  } catch (error) {
    console.error("Login error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// STUDENT ROUTES
app.get("/api/student/dashboard", authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== "student") {
      return res.status(403).json({ error: "Student access only" })
    }

    // Get student info
    const [students] = await dbPool.execute(
      `SELECT s.*, c.course_name, c.course_code
       FROM students s 
       JOIN courses c ON s.course_id = c.id 
       WHERE s.student_id = ?`,
      [req.user.username],
    )

    if (students.length === 0) {
      return res.status(404).json({ error: "Student not found" })
    }

    const student = students[0]

    // Get current system settings
    const [settings] = await dbPool.execute(
      "SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN (?, ?, ?)",
      ["current_school_year", "current_semester", "enrollment_status"],
    )

    const systemSettings = {}
    settings.forEach((setting) => {
      systemSettings[setting.setting_key] = setting.setting_value
    })

    // Check current enrollment status
    const [enrollments] = await dbPool.execute(
      `SELECT e.*, sec.section_name, sec.section_code, sec.schedule_type
       FROM enrollments e 
       JOIN sections sec ON e.section_id = sec.id 
       WHERE e.student_id = ? AND e.school_year = ? AND e.semester = ? 
       ORDER BY e.created_at DESC LIMIT 1`,
      [student.id, systemSettings.current_school_year, systemSettings.current_semester],
    )

    let currentEnrollment = null
    let enrolledSubjects = []

    if (enrollments.length > 0) {
      currentEnrollment = enrollments[0]

      // Get enrolled subjects
      const [subjects] = await dbPool.execute(
        `SELECT s.subject_code, s.subject_name, s.units, ss.time_start, ss.time_end, 
                ss.days, r.room_name, ss.instructor_name
         FROM enrollment_subjects es
         JOIN section_subjects ss ON es.section_subject_id = ss.id
         JOIN subjects s ON ss.subject_id = s.id
         LEFT JOIN rooms r ON ss.room_id = r.id
         WHERE es.enrollment_id = ? AND es.status = 'enrolled'`,
        [currentEnrollment.id],
      )

      enrolledSubjects = subjects
    }

    // Get financial accountabilities
    const [financialAccountabilities] = await dbPool.execute(
      `SELECT * FROM financial_accountabilities 
       WHERE student_id = ? AND status IN ('pending', 'overdue')
       ORDER BY due_date ASC`,
      [student.id],
    )

    // Get document requirements
    const [documentRequirements] = await dbPool.execute(
      `SELECT * FROM document_requirements 
       WHERE student_id = ? AND status IN ('pending', 'submitted', 'rejected')
       ORDER BY due_date ASC`,
      [student.id],
    )

    res.json({
      student: {
        ...student,
        isEnrolled: currentEnrollment && currentEnrollment.status === "approved",
        hasAccountabilities:
          financialAccountabilities.length > 0 ||
          documentRequirements.some((doc) => doc.status === "pending" || doc.status === "rejected"),
        currentEnrollment,
        enrolledSubjects,
        financialAccountabilities,
        documentRequirements,
      },
      systemSettings,
    })
  } catch (error) {
    console.error("Dashboard error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.get("/api/student/available-sections", authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== "student") {
      return res.status(403).json({ error: "Student access only" })
    }

    // Get student info
    const [students] = await dbPool.execute("SELECT * FROM students WHERE student_id = ?", [req.user.username])

    if (students.length === 0) {
      return res.status(404).json({ error: "Student not found" })
    }

    const student = students[0]

    // Get current system settings
    const [settings] = await dbPool.execute(
      "SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN (?, ?)",
      ["current_school_year", "current_semester"],
    )

    const systemSettings = {}
    settings.forEach((setting) => {
      systemSettings[setting.setting_key] = setting.setting_value
    })

    // Get available sections for student's course and year level
    const [sections] = await dbPool.execute(
      `SELECT s.*, (s.max_capacity - s.current_enrolled) as available_slots
       FROM sections s
       WHERE s.course_id = ? AND s.year_level = ? AND s.semester = ? 
       AND s.school_year = ? AND s.status = 'open'
       ORDER BY s.schedule_type, s.section_name`,
      [student.course_id, student.year_level, systemSettings.current_semester, systemSettings.current_school_year],
    )

    // Get subjects for each section
    const sectionsWithSubjects = await Promise.all(
      sections.map(async (section) => {
        const [subjects] = await dbPool.execute(
          `SELECT s.subject_code, s.subject_name, s.units, s.lecture_hours, s.lab_hours,
                ss.time_start, ss.time_end, ss.days, r.room_name, ss.instructor_name
         FROM section_subjects ss
         JOIN subjects s ON ss.subject_id = s.id
         LEFT JOIN rooms r ON ss.room_id = r.id
         WHERE ss.section_id = ? AND ss.is_active = TRUE
         ORDER BY s.subject_code`,
          [section.id],
        )

        const totalUnits = subjects.reduce((sum, subject) => sum + subject.units, 0)

        // Calculate fees
        const [feeSettings] = await dbPool.execute(
          "SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN (?, ?, ?)",
          ["tuition_per_unit", "misc_fee", "lab_fee_per_unit"],
        )

        const fees = {}
        feeSettings.forEach((setting) => {
          fees[setting.setting_key] = Number.parseFloat(setting.setting_value)
        })

        const labUnits = subjects.reduce((sum, subject) => sum + subject.lab_hours, 0)
        const tuitionFee = totalUnits * fees.tuition_per_unit
        const labFee = labUnits * fees.lab_fee_per_unit
        const miscFee = fees.misc_fee
        const totalFee = tuitionFee + labFee + miscFee

        return {
          ...section,
          subjects,
          totalUnits,
          tuitionFee,
          labFee,
          miscFee,
          totalFee,
          timeSlot:
            section.start_time && section.end_time
              ? `${section.start_time} - ${section.end_time}`
              : getScheduleTypeTime(section.schedule_type),
        }
      }),
    )

    res.json({ sections: sectionsWithSubjects })
  } catch (error) {
    console.error("Available sections error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

function getScheduleTypeTime(scheduleType) {
  switch (scheduleType) {
    case "morning":
      return "7:00 AM - 12:00 PM"
    case "afternoon":
      return "1:00 PM - 6:00 PM"
    case "evening":
      return "6:00 PM - 9:00 PM"
    default:
      return "TBA"
  }
}

app.post("/api/student/enroll", authenticateToken, async (req, res) => {
  const connection = await dbPool.getConnection()

  try {
    if (req.user.role !== "student") {
      return res.status(403).json({ error: "Student access only" })
    }

    const { sectionId } = req.body

    if (!sectionId) {
      return res.status(400).json({ error: "Section ID is required" })
    }

    await connection.beginTransaction()

    // Get student info
    const [students] = await connection.execute("SELECT * FROM students WHERE student_id = ?", [req.user.username])

    if (students.length === 0) {
      await connection.rollback()
      return res.status(404).json({ error: "Student not found" })
    }

    const student = students[0]

    // Check if student has accountabilities
    const [accountabilities] = await connection.execute(
      `SELECT COUNT(*) as count FROM (
         SELECT id FROM financial_accountabilities 
         WHERE student_id = ? AND status IN ('pending', 'overdue')
         UNION
         SELECT id FROM document_requirements 
         WHERE student_id = ? AND status IN ('pending', 'rejected')
       ) as combined`,
      [student.id, student.id],
    )

    if (accountabilities[0].count > 0) {
      await connection.rollback()
      return res.status(400).json({
        error: "Cannot enroll. You have pending accountabilities that must be settled first.",
      })
    }

    // Get current system settings
    const [settings] = await connection.execute(
      "SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN (?, ?)",
      ["current_school_year", "current_semester"],
    )

    const systemSettings = {}
    settings.forEach((setting) => {
      systemSettings[setting.setting_key] = setting.setting_value
    })

    // Check if already enrolled for current semester
    const [existingEnrollment] = await connection.execute(
      `SELECT id FROM enrollments 
       WHERE student_id = ? AND school_year = ? AND semester = ? 
       AND status IN ('pending', 'approved')`,
      [student.id, systemSettings.current_school_year, systemSettings.current_semester],
    )

    if (existingEnrollment.length > 0) {
      await connection.rollback()
      return res.status(400).json({
        error: "You are already enrolled or have a pending enrollment for this semester",
      })
    }

    // Get section info and check availability
    const [sections] = await connection.execute(
      `SELECT * FROM sections 
       WHERE id = ? AND status = 'open' AND current_enrolled < max_capacity`,
      [sectionId],
    )

    if (sections.length === 0) {
      await connection.rollback()
      return res.status(400).json({ error: "Section is not available or full" })
    }

    const section = sections[0]

    // Verify section matches student's course and year level
    if (section.course_id !== student.course_id || section.year_level !== student.year_level) {
      await connection.rollback()
      return res.status(400).json({ error: "Section does not match your course or year level" })
    }

    // Get section subjects
    const [sectionSubjects] = await connection.execute(
      `SELECT ss.*, s.units, s.lab_hours
       FROM section_subjects ss
       JOIN subjects s ON ss.subject_id = s.id
       WHERE ss.section_id = ? AND ss.is_active = TRUE`,
      [sectionId],
    )

    if (sectionSubjects.length === 0) {
      await connection.rollback()
      return res.status(400).json({ error: "No subjects found for this section" })
    }

    // Calculate fees
    const totalUnits = sectionSubjects.reduce((sum, subject) => sum + subject.units, 0)
    const labUnits = sectionSubjects.reduce((sum, subject) => sum + subject.lab_hours, 0)

    const [feeSettings] = await connection.execute(
      "SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN (?, ?, ?)",
      ["tuition_per_unit", "misc_fee", "lab_fee_per_unit"],
    )

    const fees = {}
    feeSettings.forEach((setting) => {
      fees[setting.setting_key] = Number.parseFloat(setting.setting_value)
    })

    const tuitionFee = totalUnits * fees.tuition_per_unit
    const labFee = labUnits * fees.lab_fee_per_unit
    const miscFee = fees.misc_fee
    const totalFee = tuitionFee + labFee + miscFee

    // Create enrollment record
    const [enrollmentResult] = await connection.execute(
      `INSERT INTO enrollments 
       (student_id, section_id, school_year, semester, total_units, tuition_fee, lab_fee, misc_fee, total_fee, status) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')`,
      [
        student.id,
        sectionId,
        systemSettings.current_school_year,
        systemSettings.current_semester,
        totalUnits,
        tuitionFee,
        labFee,
        miscFee,
        totalFee,
      ],
    )

    const enrollmentId = enrollmentResult.insertId

    // Add enrollment subjects
    for (const sectionSubject of sectionSubjects) {
      await connection.execute("INSERT INTO enrollment_subjects (enrollment_id, section_subject_id) VALUES (?, ?)", [
        enrollmentId,
        sectionSubject.id,
      ])
    }

    // Update section enrollment count
    await connection.execute("UPDATE sections SET current_enrolled = current_enrolled + 1 WHERE id = ?", [sectionId])

    await connection.commit()

    // Log audit
    await logAudit(
      req.user.id,
      "ENROLL",
      "enrollments",
      enrollmentId,
      null,
      {
        student_id: student.id,
        section_id: sectionId,
        total_fee: totalFee,
      },
      req,
    )

    res.json({
      message: "Enrollment submitted successfully! Your enrollment is pending admin approval.",
      enrollmentId,
    })
  } catch (error) {
    await connection.rollback()
    console.error("Enrollment error:", error)
    res.status(500).json({ error: "Internal server error" })
  } finally {
    connection.release()
  }
})

app.get("/api/student/grades", authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== "student") {
      return res.status(403).json({ error: "Student access only" })
    }

    const { schoolYear, semester } = req.query

    if (!schoolYear || !semester) {
      return res.status(400).json({ error: "School year and semester are required" })
    }

    // Get student ID
    const [students] = await dbPool.execute("SELECT id FROM students WHERE student_id = ?", [req.user.username])

    if (students.length === 0) {
      return res.status(404).json({ error: "Student not found" })
    }

    // Get grades
    const [grades] = await dbPool.execute(
      `SELECT sg.*, s.subject_code, s.subject_name, s.units 
       FROM student_grades sg 
       JOIN subjects s ON sg.subject_id = s.id 
       WHERE sg.student_id = ? AND sg.school_year = ? AND sg.semester = ?
       ORDER BY s.subject_code`,
      [students[0].id, schoolYear, semester],
    )

    res.json({ grades })
  } catch (error) {
    console.error("Grades error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.get("/api/student/school-years", authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== "student") {
      return res.status(403).json({ error: "Student access only" })
    }

    // Get student ID
    const [students] = await dbPool.execute("SELECT id FROM students WHERE student_id = ?", [req.user.username])

    if (students.length === 0) {
      return res.status(404).json({ error: "Student not found" })
    }

    // Get available school years from grades
    const [schoolYears] = await dbPool.execute(
      `SELECT DISTINCT school_year 
       FROM student_grades 
       WHERE student_id = ? 
       ORDER BY school_year DESC`,
      [students[0].id],
    )

    res.json({ schoolYears: schoolYears.map((row) => row.school_year) })
  } catch (error) {
    console.error("School years error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// ADMIN ROUTES
app.get("/api/admin/dashboard", authenticateToken, requireAdmin, async (req, res) => {
  try {
    // Get current system settings
    const [settings] = await dbPool.execute("SELECT setting_key, setting_value FROM system_settings")

    const systemSettings = {}
    settings.forEach((setting) => {
      systemSettings[setting.setting_key] = setting.setting_value
    })

    // Get enrollment statistics
    const [enrollmentStats] = await dbPool.execute(
      `SELECT 
         COUNT(CASE WHEN status = 'approved' THEN 1 END) as total_enrolled,
         COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_approval,
         SUM(CASE WHEN status = 'approved' THEN total_fee ELSE 0 END) as total_revenue
       FROM enrollments 
       WHERE school_year = ? AND semester = ?`,
      [systemSettings.current_school_year, systemSettings.current_semester],
    )

    // Get available slots
    const [sectionStats] = await dbPool.execute(
      `SELECT SUM(max_capacity - current_enrolled) as available_slots
       FROM sections 
       WHERE school_year = ? AND semester = ? AND status = 'open'`,
      [systemSettings.current_school_year, systemSettings.current_semester],
    )

    // Get student statistics
    const [studentStats] = await dbPool.execute(
      `SELECT 
         COUNT(*) as total_students,
         COUNT(CASE WHEN status = 'active' THEN 1 END) as active_students
       FROM students`,
    )

    res.json({
      systemSettings,
      stats: {
        ...enrollmentStats[0],
        available_slots: sectionStats[0].available_slots || 0,
        ...studentStats[0],
      },
    })
  } catch (error) {
    console.error("Admin dashboard error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.get("/api/admin/pending-enrollments", authenticateToken, requireAdmin, async (req, res) => {
  try {
    const [enrollments] = await dbPool.execute(
      `SELECT e.*, s.first_name, s.last_name, s.student_id, c.course_name, 
              sec.section_name, sec.schedule_type
       FROM enrollments e
       JOIN students s ON e.student_id = s.id
       JOIN courses c ON s.course_id = c.id
       JOIN sections sec ON e.section_id = sec.id
       WHERE e.status = 'pending'
       ORDER BY e.created_at ASC`,
    )

    res.json({ enrollments })
  } catch (error) {
    console.error("Pending enrollments error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.post("/api/admin/approve-enrollment/:id", authenticateToken, requireAdmin, async (req, res) => {
  const connection = await dbPool.getConnection()

  try {
    const enrollmentId = req.params.id

    await connection.beginTransaction()

    // Get enrollment details
    const [enrollments] = await connection.execute('SELECT * FROM enrollments WHERE id = ? AND status = "pending"', [
      enrollmentId,
    ])

    if (enrollments.length === 0) {
      await connection.rollback()
      return res.status(404).json({ error: "Enrollment not found or already processed" })
    }

    const enrollment = enrollments[0]

    // Update enrollment status
    await connection.execute(
      'UPDATE enrollments SET status = "approved", approved_by = ?, approved_at = CURRENT_TIMESTAMP WHERE id = ?',
      [req.user.id, enrollmentId],
    )

    await connection.commit()

    // Log audit
    await logAudit(
      req.user.id,
      "APPROVE_ENROLLMENT",
      "enrollments",
      enrollmentId,
      { status: "pending" },
      { status: "approved" },
      req,
    )

    res.json({ message: "Enrollment approved successfully" })
  } catch (error) {
    await connection.rollback()
    console.error("Approve enrollment error:", error)
    res.status(500).json({ error: "Internal server error" })
  } finally {
    connection.release()
  }
})

app.post("/api/admin/reject-enrollment/:id", authenticateToken, requireAdmin, async (req, res) => {
  const connection = await dbPool.getConnection()

  try {
    const enrollmentId = req.params.id
    const { reason } = req.body

    await connection.beginTransaction()

    // Get enrollment details
    const [enrollments] = await connection.execute('SELECT * FROM enrollments WHERE id = ? AND status = "pending"', [
      enrollmentId,
    ])

    if (enrollments.length === 0) {
      await connection.rollback()
      return res.status(404).json({ error: "Enrollment not found or already processed" })
    }

    const enrollment = enrollments[0]

    // Update enrollment status
    await connection.execute(
      'UPDATE enrollments SET status = "rejected", rejection_reason = ?, approved_by = ?, approved_at = CURRENT_TIMESTAMP WHERE id = ?',
      [reason, req.user.id, enrollmentId],
    )

    // Update section enrollment count
    await connection.execute("UPDATE sections SET current_enrolled = current_enrolled - 1 WHERE id = ?", [
      enrollment.section_id,
    ])

    await connection.commit()

    // Log audit
    await logAudit(
      req.user.id,
      "REJECT_ENROLLMENT",
      "enrollments",
      enrollmentId,
      { status: "pending" },
      { status: "rejected", reason },
      req,
    )

    res.json({ message: "Enrollment rejected successfully" })
  } catch (error) {
    await connection.rollback()
    console.error("Reject enrollment error:", error)
    res.status(500).json({ error: "Internal server error" })
  } finally {
    connection.release()
  }
})

app.get("/api/admin/students", authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { search, course, yearLevel, status } = req.query

    let query = `
      SELECT s.*, c.course_name, c.course_code,
             (SELECT COUNT(*) FROM financial_accountabilities fa 
              WHERE fa.student_id = s.id AND fa.status IN ('pending', 'overdue')) as financial_count,
             (SELECT COUNT(*) FROM document_requirements dr 
              WHERE dr.student_id = s.id AND dr.status IN ('pending', 'rejected')) as document_count
      FROM students s
      JOIN courses c ON s.course_id = c.id
      WHERE 1=1
    `

    const params = []

    if (search) {
      query += ` AND (s.student_id LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ?)`
      params.push(`%${search}%`, `%${search}%`, `%${search}%`)
    }

    if (course) {
      query += ` AND s.course_id = ?`
      params.push(course)
    }

    if (yearLevel) {
      query += ` AND s.year_level = ?`
      params.push(yearLevel)
    }

    if (status) {
      query += ` AND s.status = ?`
      params.push(status)
    }

    query += ` ORDER BY s.last_name, s.first_name`

    const [students] = await dbPool.execute(query, params)

    // Add accountability status
    const studentsWithAccountabilities = students.map((student) => ({
      ...student,
      hasAccountabilities: student.financial_count > 0 || student.document_count > 0,
    }))

    res.json({ students: studentsWithAccountabilities })
  } catch (error) {
    console.error("Students list error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.get("/api/admin/student/:id/accountabilities", authenticateToken, requireAdmin, async (req, res) => {
  try {
    const studentId = req.params.id

    // Get financial accountabilities
    const [financial] = await dbPool.execute(
      "SELECT * FROM financial_accountabilities WHERE student_id = ? ORDER BY created_at DESC",
      [studentId],
    )

    // Get document requirements
    const [documents] = await dbPool.execute(
      "SELECT * FROM document_requirements WHERE student_id = ? ORDER BY created_at DESC",
      [studentId],
    )

    res.json({
      financial,
      documents,
    })
  } catch (error) {
    console.error("Student accountabilities error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.post("/api/admin/student/:id/accountability", authenticateToken, requireAdmin, async (req, res) => {
  try {
    const studentId = req.params.id
    const { type, description, amount, dueDate } = req.body

    if (!type || !description) {
      return res.status(400).json({ error: "Type and description are required" })
    }

    if (type === "financial") {
      if (!amount || amount <= 0) {
        return res.status(400).json({ error: "Valid amount is required for financial accountability" })
      }

      const [result] = await dbPool.execute(
        `INSERT INTO financial_accountabilities 
         (student_id, description, amount, due_date, created_by) 
         VALUES (?, ?, ?, ?, ?)`,
        [studentId, description, amount, dueDate, req.user.id],
      )

      await logAudit(
        req.user.id,
        "ADD_FINANCIAL_ACCOUNTABILITY",
        "financial_accountabilities",
        result.insertId,
        null,
        { student_id: studentId, description, amount },
        req,
      )
    } else if (type === "document") {
      const [result] = await dbPool.execute(
        `INSERT INTO document_requirements 
         (student_id, document_name, description, due_date, created_by) 
         VALUES (?, ?, ?, ?, ?)`,
        [studentId, description, req.body.documentDescription || "", dueDate, req.user.id],
      )

      await logAudit(
        req.user.id,
        "ADD_DOCUMENT_REQUIREMENT",
        "document_requirements",
        result.insertId,
        null,
        { student_id: studentId, document_name: description },
        req,
      )
    }

    res.json({ message: "Accountability added successfully" })
  } catch (error) {
    console.error("Add accountability error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.delete("/api/admin/accountability/:type/:id", authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { type, id } = req.params

    if (type === "financial") {
      const [result] = await dbPool.execute("DELETE FROM financial_accountabilities WHERE id = ?", [id])

      if (result.affectedRows === 0) {
        return res.status(404).json({ error: "Financial accountability not found" })
      }

      await logAudit(req.user.id, "DELETE_FINANCIAL_ACCOUNTABILITY", "financial_accountabilities", id, null, null, req)
    } else if (type === "document") {
      const [result] = await dbPool.execute("DELETE FROM document_requirements WHERE id = ?", [id])

      if (result.affectedRows === 0) {
        return res.status(404).json({ error: "Document requirement not found" })
      }

      await logAudit(req.user.id, "DELETE_DOCUMENT_REQUIREMENT", "document_requirements", id, null, null, req)
    } else {
      return res.status(400).json({ error: "Invalid accountability type" })
    }

    res.json({ message: "Accountability removed successfully" })
  } catch (error) {
    console.error("Remove accountability error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.post("/api/admin/toggle-enrollment", authenticateToken, requireAdmin, async (req, res) => {
  try {
    // Get current enrollment status
    const [current] = await dbPool.execute(
      'SELECT setting_value FROM system_settings WHERE setting_key = "enrollment_status"',
    )

    const newStatus = current[0].setting_value === "open" ? "closed" : "open"

    // Update enrollment status
    await dbPool.execute(
      'UPDATE system_settings SET setting_value = ?, updated_by = ? WHERE setting_key = "enrollment_status"',
      [newStatus, req.user.id],
    )

    await logAudit(
      req.user.id,
      "TOGGLE_ENROLLMENT",
      "system_settings",
      null,
      { enrollment_status: current[0].setting_value },
      { enrollment_status: newStatus },
      req,
    )

    res.json({
      message: `Enrollment ${newStatus === "open" ? "opened" : "closed"} successfully`,
      status: newStatus,
    })
  } catch (error) {
    console.error("Toggle enrollment error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.get("/api/admin/courses", authenticateToken, requireAdmin, async (req, res) => {
  try {
    const [courses] = await dbPool.execute("SELECT * FROM courses WHERE is_active = TRUE ORDER BY course_name")

    res.json({ courses })
  } catch (error) {
    console.error("Courses error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.get("/api/admin/sections", authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { schoolYear, semester } = req.query

    const [sections] = await dbPool.execute(
      `SELECT s.*, c.course_name, c.course_code,
              COUNT(e.id) as enrolled_count
       FROM sections s
       JOIN courses c ON s.course_id = c.id
       LEFT JOIN enrollments e ON s.id = e.section_id AND e.status = 'approved'
       WHERE s.school_year = ? AND s.semester = ?
       GROUP BY s.id
       ORDER BY c.course_name, s.year_level, s.section_name`,
      [schoolYear || "2024-2025", semester || "1"],
    )

    res.json({ sections })
  } catch (error) {
    console.error("Sections error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// DOCUMENT UPLOAD ROUTES
app.post(
  "/api/student/upload-document/:requirementId",
  authenticateToken,
  upload.single("document"),
  async (req, res) => {
    try {
      if (req.user.role !== "student") {
        return res.status(403).json({ error: "Student access only" })
      }

      const requirementId = req.params.requirementId

      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" })
      }

      // Get student ID
      const [students] = await dbPool.execute("SELECT id FROM students WHERE student_id = ?", [req.user.username])

      if (students.length === 0) {
        return res.status(404).json({ error: "Student not found" })
      }

      // Verify document requirement belongs to student
      const [requirements] = await dbPool.execute(
        "SELECT * FROM document_requirements WHERE id = ? AND student_id = ?",
        [requirementId, students[0].id],
      )

      if (requirements.length === 0) {
        return res.status(404).json({ error: "Document requirement not found" })
      }

      // Update document requirement with file path
      await dbPool.execute(
        `UPDATE document_requirements 
       SET file_path = ?, status = 'submitted', submitted_date = CURRENT_TIMESTAMP 
       WHERE id = ?`,
        [req.file.path, requirementId],
      )

      await logAudit(
        req.user.id,
        "UPLOAD_DOCUMENT",
        "document_requirements",
        requirementId,
        null,
        { file_path: req.file.path },
        req,
      )

      res.json({
        message: "Document uploaded successfully",
        filename: req.file.filename,
      })
    } catch (error) {
      console.error("Document upload error:", error)
      res.status(500).json({ error: "Internal server error" })
    }
  },
)

// SYSTEM SETTINGS ROUTES
app.get("/api/system/settings", async (req, res) => {
  try {
    const [settings] = await dbPool.execute(
      "SELECT setting_key, setting_value, data_type FROM system_settings WHERE is_public = TRUE",
    )

    const publicSettings = {}
    settings.forEach((setting) => {
      let value = setting.setting_value

      // Convert based on data type
      if (setting.data_type === "number") {
        value = Number.parseFloat(value)
      } else if (setting.data_type === "boolean") {
        value = value === "true"
      } else if (setting.data_type === "json") {
        try {
          value = JSON.parse(value)
        } catch (e) {
          value = setting.setting_value
        }
      }

      publicSettings[setting.setting_key] = value
    })

    res.json({ settings: publicSettings })
  } catch (error) {
    console.error("System settings error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// ERROR HANDLING MIDDLEWARE
app.use((error, req, res, next) => {
  console.error("Unhandled error:", error)

  if (error instanceof multer.MulterError) {
    if (error.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ error: "File too large. Maximum size is 5MB." })
    }
  }

  res.status(500).json({ error: "Internal server error" })
})

// 404 HANDLER
app.use("*", (req, res) => {
  res.status(404).json({ error: "Endpoint not found" })
})

// GRACEFUL SHUTDOWN
process.on("SIGTERM", async () => {
  console.log("SIGTERM received, shutting down gracefully")
  await dbPool.end()
  process.exit(0)
})

process.on("SIGINT", async () => {
  console.log("SIGINT received, shutting down gracefully")
  await dbPool.end()
  process.exit(0)
})

app.listen(PORT, () => {
  console.log(`NCST Enrollment System API running on port ${PORT}`)
  console.log(`Environment: ${process.env.NODE_ENV || "development"}`)
})

module.exports = app
