#!/bin/bash

echo "🚀 Deploying NCST Enrollment System..."

# Pull latest changes
git pull origin main

# Install/update dependencies
npm ci --only=production

# Run database migrations if needed
echo "📊 Checking database..."
# Add migration commands here if needed

# Restart application with PM2
if command -v pm2 &> /dev/null; then
    echo "🔄 Restarting application with PM2..."
    pm2 restart ncst-enrollment
else
    echo "⚠️  PM2 not found. Please install PM2 for production deployment."
fi

echo "✅ Deployment complete!"
