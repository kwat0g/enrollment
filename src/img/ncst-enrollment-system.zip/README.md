# NCST Enrollment System

A comprehensive web-based enrollment system built with Vue.js, Node.js, Express.js, and MySQL.

## Features

### Student Features
- Secure login with Student ID and Last Name
- Dashboard with enrollment status and accountabilities
- Online enrollment for available sections
- Grade viewing by semester
- Document upload for requirements
- Financial accountability tracking

### Admin Features
- Dashboard with enrollment statistics
- Approve/reject student enrollments
- Manage student accountabilities
- System settings management
- Student management
- Audit logging

## Tech Stack

- **Frontend**: Vue.js 3, Tailwind CSS
- **Backend**: Node.js, Express.js
- **Database**: MySQL
- **Authentication**: JWT
- **File Upload**: Multer

## Prerequisites

- Node.js (v16 or higher)
- MySQL (v8.0 or higher)
- npm or yarn

## Installation & Setup

### 1. Clone the Repository

\`\`\`bash
git clone <repository-url>
cd ncst-enrollment-system
\`\`\`

### 2. Database Setup

1. Install MySQL and create a database:
\`\`\`sql
CREATE DATABASE ncst_enrollment;
\`\`\`

2. Import the database schema:
\`\`\`bash
mysql -u root -p ncst_enrollment < database/schema.sql
\`\`\`

### 3. Backend Setup

1. Install dependencies:
\`\`\`bash
npm install
\`\`\`

2. Create environment file:
\`\`\`bash
cp .env.example .env
\`\`\`

3. Configure your `.env` file:
\`\`\`env
# Database Configuration
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=ncst_enrollment

# JWT Secret
JWT_SECRET=your-super-secret-jwt-key-here

# Server Configuration
PORT=3000
NODE_ENV=development

# Frontend URL (for CORS)
FRONTEND_URL=http://localhost:8080
\`\`\`

4. Start the backend server:
\`\`\`bash
npm start
\`\`\`

The API will be available at `http://localhost:3000`

### 4. Frontend Setup

1. Install a simple HTTP server (if you don't have one):
\`\`\`bash
npm install -g http-server
\`\`\`

2. Serve the Vue.js application:
\`\`\`bash
http-server . -p 8080 -c-1
\`\`\`

The frontend will be available at `http://localhost:8080`

## Default Login Credentials

### Admin Account
- **Username**: admin
- **Password**: admin

### Student Accounts
- **Student ID**: 2021-001234, **Last Name**: Doe
- **Student ID**: 2021-001235, **Last Name**: Santos
- **Student ID**: 2022-001237, **Last Name**: Rodriguez

## API Endpoints

### Authentication
- `POST /api/auth/login` - User login

### Student Endpoints
- `GET /api/student/dashboard` - Get student dashboard data
- `GET /api/student/available-sections` - Get available sections for enrollment
- `POST /api/student/enroll` - Submit enrollment
- `GET /api/student/grades` - Get student grades
- `GET /api/student/school-years` - Get available school years
- `POST /api/student/upload-document/:requirementId` - Upload document

### Admin Endpoints
- `GET /api/admin/dashboard` - Get admin dashboard stats
- `GET /api/admin/pending-enrollments` - Get pending enrollments
- `POST /api/admin/approve-enrollment/:id` - Approve enrollment
- `POST /api/admin/reject-enrollment/:id` - Reject enrollment
- `GET /api/admin/students` - Get students list
- `GET /api/admin/student/:id/accountabilities` - Get student accountabilities
- `POST /api/admin/student/:id/accountability` - Add accountability
- `DELETE /api/admin/accountability/:type/:id` - Remove accountability
- `POST /api/admin/toggle-enrollment` - Toggle enrollment status
- `GET /api/admin/courses` - Get courses
- `GET /api/admin/sections` - Get sections

### System Endpoints
- `GET /api/system/settings` - Get public system settings

## Project Structure

\`\`\`
ncst-enrollment-system/
├── database/
│   └── schema.sql          # Database schema and seed data
├── uploads/                # File uploads directory
├── server.js              # Main server file
├── app.vue                # Vue.js frontend application
├── package.json           # Node.js dependencies
├── .env.example           # Environment variables template
└── README.md              # This file
\`\`\`

## Development

### Running in Development Mode

1. Start the backend with auto-reload:
\`\`\`bash
npm run dev
\`\`\`

2. Start the frontend with live reload:
\`\`\`bash
http-server . -p 8080 -c-1
\`\`\`

### Database Management

To reset the database:
\`\`\`bash
mysql -u root -p ncst_enrollment < database/schema.sql
\`\`\`

To backup the database:
\`\`\`bash
mysqldump -u root -p ncst_enrollment > backup.sql
\`\`\`

## Production Deployment

### Using PM2 (Recommended)

1. Install PM2:
\`\`\`bash
npm install -g pm2
\`\`\`

2. Start the application:
\`\`\`bash
pm2 start ecosystem.config.js
\`\`\`

3. Set up PM2 to start on boot:
\`\`\`bash
pm2 startup
pm2 save
\`\`\`

### Using Docker

1. Build the Docker image:
\`\`\`bash
docker build -t ncst-enrollment .
\`\`\`

2. Run with Docker Compose:
\`\`\`bash
docker-compose up -d
\`\`\`

### Environment Variables for Production

\`\`\`env
NODE_ENV=production
DB_HOST=your-production-db-host
DB_USER=your-production-db-user
DB_PASSWORD=your-production-db-password
DB_NAME=ncst_enrollment
JWT_SECRET=your-super-secure-jwt-secret
PORT=3000
FRONTEND_URL=https://your-domain.com
\`\`\`

## Security Considerations

1. **Change Default Passwords**: Update all default passwords before deployment
2. **JWT Secret**: Use a strong, unique JWT secret
3. **Database Security**: Use strong database credentials
4. **HTTPS**: Always use HTTPS in production
5. **File Upload**: Validate and sanitize uploaded files
6. **Rate Limiting**: Implement rate limiting for API endpoints

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Check MySQL is running
   - Verify database credentials in `.env`
   - Ensure database exists

2. **CORS Errors**
   - Check `FRONTEND_URL` in `.env`
   - Ensure frontend and backend URLs match

3. **File Upload Issues**
   - Check `uploads/` directory permissions
   - Verify file size limits

4. **Login Issues**
   - Verify user exists in database
   - Check password hashing
   - Ensure JWT secret is set

### Logs

Check application logs:
\`\`\`bash
# Development
npm run dev

# Production with PM2
pm2 logs ncst-enrollment
\`\`\`

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

For support, please contact the development team or create an issue in the repository.
